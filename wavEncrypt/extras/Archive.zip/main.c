#include <stdio.h>
#include "wav.h"

int main(int argc, char *argv[]){
	
	wav_t wav = newWavFromFile(argv[1]);
	
	printf("Wav: %p\n",wav);
	printf("Result: %d\n", wavWriteToFile(wav,argv[2]));
	
	
	return 0;
	
	
}