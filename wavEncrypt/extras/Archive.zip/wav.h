#include <stdio.h>

#include "types.h"

typedef struct wavCDT *wav_t;


wav_t newWavFromFile(char *path);

int wavWriteToFile(wav_t wav, char *path);

void nothing();